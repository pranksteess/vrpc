/*
 * CObject.cpp
 *
 *  Created on: 2013-3-8
 *      Author: rogeryang
 */

#include "CObject.h"

namespace vrpc
{
namespace base
{

    CObject::CObject()
    {
    }

    CObject::~CObject()
    {
    }

} /* namespace base */
} /* namespace vrpc */
