#ifndef __SPP_VERSION_H__
#define __SPP_VERSION_H__

__attribute__((weak)) char SPP_VERSION[64] = "spp version: spp 2.7.1 release 0001";

#endif
