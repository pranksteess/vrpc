#!/bin/sh
#use protoc gen code for php

#_pkg_dir_php=/data/home/ryanfan/svn/isd_qqvipserver_rep/VipRpc/protobuf_cpp_service/pkg_resource/php/
_pkg_dir_php=/usr/local/services/vrpc_gen-2.3/pkg_resource/php/

if [ $# -ne 3 ]; then
echo "usage: $0 proto_file_path proto_file output_dir"
exit 1
fi

_proto_file_path=$1
_proto_file=$2
_output_dir=$3


#make proj dir
mkdir -p $_output_dir/
cd $_output_dir/
mkdir lib
mkdir message
mkdir proto

cp $_proto_file proto/
cp -rf $_pkg_dir_php/lib/* lib/
cp -rf $_pkg_dir_php/message/* message/


#gen php & service code
cd $_pkg_dir_php/parser
/usr/local/services/php-5.2.14/bin/php -f magic.php $_proto_file $_output_dir/ $_pkg_dir_php
if [ $? -ne 0 ]; then
echo "protoc gen php exec error"
exit 1
fi
